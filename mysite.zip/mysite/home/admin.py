from django.contrib import admin
from .models import Requests

# Register your models here.

admin.site.register(Requests)
